Nova - Android project
1. Android Studio (Koala या नया) डाउनलोड करें: developer.android.com/studio
2. File > Open > यह NovaApp फ़ोल्डर चुनें, Gradle sync पूरा होने दें
3. फ़ोन में USB debugging चालू करके जोड़ें, फिर Run (हरा बटन)
   APK फ़ाइल: Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
4. ऐप खोलकर Settings में API key डालें
